<?php
$conn = mysqli_connect("localhost", "lizakt_la1994", "hms123", "lizakt_la1994");
$info = json_decode(file_get_contents("php://input"));
if (count($info) > 0) {
    $name     = mysqli_real_escape_string($conn, $info->name);
    $email    = mysqli_real_escape_string($conn, $info->email);
    $age      = mysqli_real_escape_string($conn, $info->age);
    $mobile      = mysqli_real_escape_string($conn, $info->mobile);
    echo $name;
    $btn_name = $info->btnName;
    if ($btn_name == "Insert") {
        $query = "INSERT INTO insert_emp_info(name, email, age,mobile) VALUES ('$name', '$email', '$age','$mobile')";
        if (mysqli_query($conn, $query)) {
            echo "Data Inserted Successfully...";
        } else {
            echo 'Failed';
        }
    }
    if ($btn_name == 'Update') {
        $id    = $info->id;
        $query = "UPDATE insert_emp_info SET name = '$name', email = '$email', age = '$age', mobile = '$mobile' WHERE id = '$id'";
        if (mysqli_query($conn, $query)) {
            echo 'Data Updated Successfully...';
        } else {
            echo 'Failed';
        }
    }
}
?>